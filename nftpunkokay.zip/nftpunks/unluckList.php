<?php



if(isset($_GET['log'])){
    


 echo "<script>window.open('sent')</script>";




}





?>